"""
MUSICDATA - Remote music file reference format
Store remote file links (Google Drive, Dropbox, URLs, etc.) with IDs
Access music by ID from anywhere in your application

Syntax: port "FILE_LINK" id "NAME"
"""

import re
import json


class MusicData:
    def __init__(self):
        self.entries = {}  # {id: file_link}
    
    def add_entry(self, file_link, id_name):
        """Add a remote file link with an ID"""
        self.entries[id_name] = file_link
    
    def get(self, id_name):
        """Get file link by ID"""
        return self.entries.get(id_name)
    
    def save(self, filename):
        """Save to .musicdata file"""
        if not filename.endswith('.musicdata'):
            filename += '.musicdata'
        
        with open(filename, 'w') as f:
            for id_name, file_link in self.entries.items():
                f.write(f'port "{file_link}" id "{id_name}"\n')
        
        print(f"✓ Saved {len(self.entries)} entry(s) to {filename}")
    
    @classmethod
    def load(cls, filename):
        """Load from .musicdata file"""
        music = cls()
        
        with open(filename, 'r') as f:
            content = f.read()
        
        # Parse: port "FILE_LINK" id "NAME"
        # Case-insensitive: port, PORT, Port
        pattern = r'(?:port|PORT|Port)\s+"([^"]+)"\s+id\s+"([^"]+)"'
        matches = re.findall(pattern, content)
        
        for file_link, id_name in matches:
            music.entries[id_name] = file_link
        
        print(f"✓ Loaded {len(music.entries)} entry(s) from {filename}")
        return music
    
    def list_ids(self):
        """Get all available IDs"""
        return list(self.entries.keys())
    
    def get_all(self):
        """Get all entries as dictionary"""
        return self.entries.copy()
    
    def __repr__(self):
        return f"MusicData({len(self.entries)} entries: {list(self.entries.keys())})"


# Convenience function for importing
def load(filename):
    """Load a .musicdata file"""
    return MusicData.load(filename)


if __name__ == "__main__":
    print("=" * 50)
    print("MUSICDATA Format Demo")
    print("=" * 50)
    print()
    
    # Create a new MusicData file
    music = MusicData()
    
    # Add remote file links with IDs
    music.add_entry("https://drive.google.com/file/d/abc123/intro.mp3", "intro")
    music.add_entry("https://myserver.com/audio/main_theme.wav", "main_theme")
    music.add_entry("https://dropbox.com/s/xyz789/battle.ogg", "battle")
    music.add_entry("https://cdn.example.com/music/credits.mp3", "credits")
    
    # Save it
    music.save("app_music.musicdata")
    
    print()
    print("File contents:")
    print("-" * 50)
    with open("app_music.musicdata", 'r') as f:
        print(f.read())
    
    print("-" * 50)
    print()
    
    # Load it back
    loaded = load("app_music.musicdata")
    print(loaded)
    print()
    
    # Access by ID
    print("Access music by ID:")
    print(f"  'intro' → {loaded.get('intro')}")
    print(f"  'battle' → {loaded.get('battle')}")
    print(f"  'main_theme' → {loaded.get('main_theme')}")
    print()
    
    print(f"All IDs: {loaded.list_ids()}")
    print()
    print("✓ Now you can use these links anywhere in your app!")

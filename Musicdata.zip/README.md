# MUSICDATA Format

Store remote music file links with IDs.

## Format
```
port "FILE_LINK" id "NAME"
```

## Example File (playlist.musicdata)
```
port "https://drive.google.com/file/song.mp3" id "main_song"
port "https://myserver.com/drums.wav" id "drums"
```

## Usage
```python
import musicdata

# Load file
music = musicdata.load("playlist.musicdata")

# Get link by ID
url = music.get("main_song")

# List all IDs
ids = music.list_ids()
```

## Creating Files
```python
import musicdata

music = musicdata.MusicData()
music.add_entry("https://example.com/song.mp3", "my_song")
music.save("output.musicdata")
```
